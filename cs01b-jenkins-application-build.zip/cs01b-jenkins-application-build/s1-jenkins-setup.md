#SETUP JENKINS

[install]
[version] :2.150.3
run jenkins.msi from jenkins-2.150.3 folder
check windows service : jenkins {status:running}
unlock jenkins : http://localhost:8080 or http://localhost:8080/jenkins
password : C:\Program Files (x86)\Jenkins\secrets\initialAdminPassword
Install suggested plugins

[bugs]
Jenkins Setup Wizard Blank Page
[soln] restart jenkins

[run] http://localhost:8080/
Access welcome page for user created [jenkins]

#SETUP MAVEN
[Chocolatey] - The package manager for Windows
choco install maven
or
[manual-install]

[run]
mvn -v
Apache Maven 3.6.0

